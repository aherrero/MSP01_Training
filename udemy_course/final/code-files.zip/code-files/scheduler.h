#ifndef SCHEDULER_H_
#define SCHEDULER_H_


typedef struct Task {
    void (*taskFunction)(void); // Function that task executes
    unsigned long period;       // How often it should happen in timer ticks
    unsigned char repeat;       // If task should be repeated
    unsigned long elapsedTime;  // Keep track of how many timer ticks have elapsed
} Task;


void scheduler_create_task(void (*func)(void), int period, unsigned char repeat);
void scheduler_execute_task(void);


#endif /* SCHEDULER_H_ */
