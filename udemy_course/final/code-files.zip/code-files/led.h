#ifndef LED_H_
#define LED_H_


#define LED_GREEN   0x01
#define LED_YELLOW  0x02
#define LED_RED     0x04


void led_init(void);
void led_green_blink(void);
void led_yellow_blink(void);
void led_red_blink(void);

void led_clear(void);
void led_toggle(void);
void led_green_on(void);
void led_green_off(void);
void led_yellow_on(void);
void led_yellow_off(void);
void led_red_on(void);
void led_red_off(void);

#endif /* LED_H_ */
