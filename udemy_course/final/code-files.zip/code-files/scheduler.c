#include "scheduler.h"
#include "led.h"


#define TASK_MAX    16


Task taskList[TASK_MAX];
unsigned int taskCount = 0;


void scheduler_delete_task(int index);


void scheduler_create_task(void (*func)(void), int period, unsigned char repeat)
{
    Task taskToAdd;
    taskToAdd.taskFunction = func;
    taskToAdd.period = period * 8;  // Keep period at 1 second intervals
    taskToAdd.repeat = repeat;
    taskToAdd.elapsedTime = 0;      // Initialize elapsed time to 0

    taskList[taskCount++] = taskToAdd;
}


void scheduler_execute_task(void)
{
    unsigned int i;
    for(i = 0; i < taskCount; i++)
    {
        taskList[i].elapsedTime++;

        if(taskList[i].elapsedTime >= taskList[i].period)
        {
            taskList[i].elapsedTime = 0;
            taskList[i].taskFunction();

            // If the task isn't supposed to repeat, remove it
            if(taskList[i].repeat == 0)
            {
                scheduler_delete_task(i);
            }
        }
    }
}


void scheduler_delete_task(int index)
{
   int i;
   for(i = index; i < taskCount - 1; i++)
   {
       taskList[i] = taskList[i + 1];
   }

   taskCount--;
}
