#include <msp430.h> 
#include "timer.h"
#include "led.h"
#include "scheduler.h"


unsigned char ledToggleFlag = 0;
unsigned char executeTaskFlag = 0;

unsigned char ledBlinkFlag = 0;
unsigned char ledBlinkColorRegister = 0;

/**
 * main.c
 */
int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	led_init();

	timer_init();

	// Create our tasks
	scheduler_create_task(led_green_blink, 1, 1);
	scheduler_create_task(led_yellow_blink, 2, 1);
	scheduler_create_task(led_red_blink, 3, 1);

	// Main program loop
	while(1)
	{
	    if (executeTaskFlag == 1)
	    {
	        executeTaskFlag = 0;
	        scheduler_execute_task();
	    }

	    // Blink one of our LEDs
	    if (ledBlinkFlag == 1)
	    {
	        ledBlinkFlag = 0;

            if (ledBlinkColorRegister & LED_GREEN)
            {
                led_green_on();
            }
	        if (ledBlinkColorRegister & LED_YELLOW)
            {
                led_yellow_on();
            }
            if (ledBlinkColorRegister & LED_RED)
            {
                led_red_on();
            }
	    }
	    else
	    {
	        led_clear();
	    }

	    // Check to see if LED should be toggled
	    if (ledToggleFlag == 1)
	    {
	        ledToggleFlag = 0;
	        led_toggle();
	    }

	    // Go to sleep
	    __bis_SR_register(LPM0_bits + GIE);
	}
}
