#include "led.h"
#include <msp430.h>


extern unsigned char ledBlinkFlag;
extern unsigned char ledBlinkColorRegister;

void led_init(void)
{
    P1DIR |= BIT0; // On board LED
    P1DIR |= BIT6; // Green LED
    P3DIR |= BIT3; // Yellow LED
    P3DIR |= BIT4; // Red LED

    // Make sure all three are off
    led_clear();
}

void led_green_blink(void)
{
    ledBlinkColorRegister |= LED_GREEN;
    ledBlinkFlag = 1;
}

void led_yellow_blink(void)
{
    ledBlinkColorRegister |= LED_YELLOW;
    ledBlinkFlag = 1;
}

void led_red_blink(void)
{
    ledBlinkColorRegister |= LED_RED;
    ledBlinkFlag = 1;
}

void led_clear(void)
{
    led_green_off();
    led_yellow_off();
    led_red_off();

    // Clear register
    ledBlinkColorRegister = 0;
}

void led_toggle(void)
{
    P1OUT ^= BIT0;
}

void led_green_on(void)
{
    P1OUT |= BIT6;
}

void led_green_off(void)
{
    P1OUT &= ~BIT6;
}

void led_yellow_on(void)
{
    P3OUT |= BIT3;
}

void led_yellow_off(void)
{
    P3OUT &= ~BIT3;
}

void led_red_on(void)
{
    P3OUT |= BIT4;
}

void led_red_off(void)
{
    P3OUT &= ~BIT4;
}
