#include "led.h"
#include <msp430.h>


void led_init(void)
{
    P1DIR |= BIT0; // On board LED
    P1DIR |= BIT6; // Green LED
    P3DIR |= BIT3; // Yellow LED
    P3DIR |= BIT4; // Red LED

    // Make sure all three are off
    led_green_off();
    led_yellow_off();
    led_red_off();
}

void led_toggle(void)
{
    P1OUT ^= BIT0;
}

void led_green_on(void)
{
    P1OUT |= BIT6;
}

void led_green_off(void)
{
    P1OUT &= ~BIT6;
}

void led_yellow_on(void)
{
    P3OUT |= BIT3;
}

void led_yellow_off(void)
{
    P3OUT &= ~BIT3;
}

void led_red_on(void)
{
    P3OUT |= BIT4;
}

void led_red_off(void)
{
    P3OUT &= ~BIT4;
}
