#include <msp430.h> 
#include "timer.h"
#include "led.h"
#include "scheduler.h"


struct Task ledTimingTask;

unsigned char ledToggleFlag = 0;
unsigned char executeTaskFlag = 0;

/**
 * main.c
 */
int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	led_init();

	timer_init();

	// Set up a task that turns the LEDs on after three seconds
	ledTimingTask.period = 3 * 8;   // 3 times 8 since each tick is 1/8 second
	ledTimingTask.elapsedTime = 0;  // Initialize to 0

	// Main program loop
	while(1)
	{
	    if (executeTaskFlag == 1)
	    {
	        executeTaskFlag = 0;
	        scheduler_execute_task();
	    }

	    // Check to see if LED should be toggled
	    if (ledToggleFlag == 1)
	    {
	        ledToggleFlag = 0;
	        led_toggle();
	    }

	    // Go to sleep
	    __bis_SR_register(LPM0_bits + GIE);
	}
}
