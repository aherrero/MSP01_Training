#ifndef SCHEDULER_H_
#define SCHEDULER_H_


typedef struct Task {
    unsigned long period;       // How often it should happen in timer ticks
    unsigned long elapsedTime;  // Keep track of how many timer ticks have elapsed
};


void scheduler_execute_task(void);


#endif /* SCHEDULER_H_ */
