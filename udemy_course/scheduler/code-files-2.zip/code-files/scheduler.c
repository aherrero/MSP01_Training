#include "scheduler.h"
#include "led.h"


extern struct Task ledTimingTask;


void scheduler_execute_task(void)
{
    // Increment the task elapsed time
    ledTimingTask.elapsedTime++;

    // Check to see if task is ready
    if (ledTimingTask.elapsedTime >= ledTimingTask.period) {
        led_yellow_on();
        led_green_on();
        led_red_on();
    }
}
