#include "timer.h"
#include <msp430.h>


unsigned int timerCount = 0;    // Keep track of timer ticks

extern unsigned char ledToggleFlag;
extern unsigned char executeTaskFlag;


void timer_init(void)
{
    unsigned int timerSettings = 0;
    timerSettings |= 0x0100;    // Choose ACLK
    timerSettings |= 0x0010;    // Count up mode
    timerSettings |= 0x0004;    // Clear the timer;
    TA0CTL = timerSettings;     // Map settings to control register

    TA0CCTL0 = 0x0010;          // Enable interrupt in capture and control register
    TA0CCR0 = 4096;             // Set capture and control threshold to 1/8 of 32kHz clock
}



#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
    timerCount++;

    // Timer is 1/8 of a second, so count up to 8 for 1 second toggle
    if (timerCount >= 8)
    {
        timerCount = 0;

        // Set flag to toggle the led in the main loop
        ledToggleFlag = 1;
    }

    // Check timing of tasks to execute
    executeTaskFlag = 1;

    // Wake up MCU so that main loop executes
    __bic_SR_register_on_exit(LPM0_bits);
}
